# trainer.py
import cv2
import numpy as np
import os
import json

DATASET_DIR = "dataset"
NAMES_FILE = "names.json"
TRAINER_FILE = "trainer.yml"

def train_model():
    if not os.path.exists(DATASET_DIR):
        print("Dataset folder not found. Run creator.py first!")
        return

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces = []
    ids = []

    print("Loading images for training...")
    for filename in os.listdir(DATASET_DIR):
        if filename.startswith("User.") and filename.endswith(".jpg"):
            path = os.path.join(DATASET_DIR, filename)
            gray_img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            id_str = filename.split(".")[1]
            faces.append(gray_img)
            ids.append(int(id_str))

    if len(faces) == 0:
        print("No images found in dataset folder!")
        return

    print(f"Training model with {len(faces)} images...")
    recognizer.train(faces, np.array(ids))
    recognizer.save(TRAINER_FILE)
    print(f"✅ Model trained successfully and saved to {TRAINER_FILE}")

    # Show available names
    if os.path.exists(NAMES_FILE):
        with open(NAMES_FILE, "r", encoding="utf-8") as f:
            names = json.load(f)
        print(f"Trained IDs: {names}")
    else:
        print("No names.json file found. But trainer.yml is created.")

if __name__ == "__main__":
    train_model()
