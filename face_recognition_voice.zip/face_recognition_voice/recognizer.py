import cv2
import json
import pyttsx3
import os
import time
import threading

HAAR_FILE = "haarcascade_frontalface_default.xml"
TRAINER_FILE = "trainer.yml"
NAMES_FILE = "names.json"

# Initialize TTS engine once
engine = pyttsx3.init()

def speak(text):
    # Run speaking in a separate thread so video won't freeze
    t = threading.Thread(target=_speak, args=(text,))
    t.daemon = True
    t.start()

def _speak(text):
    engine.say(text)
    engine.runAndWait()

def main():
    if not os.path.exists(TRAINER_FILE):
        print("Trainer file not found! Run trainer.py first.")
        return

    # Load names
    with open(NAMES_FILE, "r", encoding="utf-8") as f:
        names = json.load(f)

    # Load trained model
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(TRAINER_FILE)

    # Load Haar Cascade
    face_cascade = cv2.CascadeClassifier(HAAR_FILE)

    cam = cv2.VideoCapture(0)
    print("Camera started. Press 'q' to quit.")

    # Give camera 1 sec to warm up
    time.sleep(1)

    last_spoken_time = {}

    while True:
        ret, frame = cam.read()
        if not ret:
            print("Failed to grab frame.")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

        for (x, y, w, h) in faces:
            face_img = gray[y:y+h, x:x+w]
            face_resized = cv2.resize(face_img, (200, 200))

            id_predicted, confidence = recognizer.predict(face_resized)
            name = names.get(str(id_predicted), "Unknown")

            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(frame, f"{name} ({confidence:.1f})", (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

            if confidence < 80:  # Good match
                now = time.time()
                last_spoken = last_spoken_time.get(id_predicted, 0)

                if now - last_spoken > 3:  # Speak only every 3 sec per person
                    speak(f"Hello {name}")
                    last_spoken_time[id_predicted] = now
            else:
                cv2.putText(frame, "Unknown", (x, y-30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        cv2.imshow("Face Recognition", frame)
        k = cv2.waitKey(1) & 0xFF
        if k == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
