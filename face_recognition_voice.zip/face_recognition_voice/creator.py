import cv2
import os
import json
import time

# Always load file from same folder as this script
BASE_DIR = os.path.dirname(__file__)
HAAR_FILE = os.path.join(BASE_DIR, "haarcascade_frontalface_default.xml")
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
NAMES_FILE = os.path.join(BASE_DIR, "names.json")
TARGET_IMAGES = 40

def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d)

def load_names():
    if os.path.exists(NAMES_FILE):
        with open(NAMES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_names(names):
    with open(NAMES_FILE, "w", encoding="utf-8") as f:
        json.dump(names, f, indent=4, ensure_ascii=False)

def main():
    if not os.path.exists(HAAR_FILE):
        print(f"ERROR: {HAAR_FILE} not found. Put it in the project folder.")
        return

    ensure_dir(DATASET_DIR)
    names = load_names()

    user_id = input("Enter numeric ID for this person (e.g. 1): ").strip()
    if not user_id.isdigit():
        print("ID must be a number. Run again.")
        return
    user_id = str(int(user_id))

    name = input("Enter name for this ID (e.g. Chandra Sekhar): ").strip()
    if not name:
        print("Name cannot be empty. Run again.")
        return

    names[user_id] = name
    save_names(names)
    print(f"Saved mapping: {user_id} -> {name}")

    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        print("Cannot open camera. Check camera index.")
        return

    face_cascade = cv2.CascadeClassifier(HAAR_FILE)
    count = 0
    print("Starting camera. Look at the camera. Press 'q' to quit early.")

    while True:
        ret, frame = cam.read()
        if not ret:
            print("Failed to grab frame.")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

        if len(faces) > 0:
            # choose the largest face (avoid multiple people confusion)
            x, y, w, h = max(faces, key=lambda rect: rect[2]*rect[3])
            face_img = gray[y:y+h, x:x+w]
            face_resized = cv2.resize(face_img, (200, 200))
            count += 1
            filename = os.path.join(DATASET_DIR, f"User.{user_id}.{count}.jpg")
            cv2.imwrite(filename, face_resized)
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(frame, f"{name} {count}/{TARGET_IMAGES}", (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

            # small delay so frames are not identical
            time.sleep(0.15)

        cv2.imshow("Capture Faces - Press 'q' to quit", frame)
        k = cv2.waitKey(1) & 0xFF
        if k == ord('q'):
            break
        if count >= TARGET_IMAGES:
            break

    print(f"Captured {count} images for ID={user_id} ({name})")
    cam.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
