import cv2
import os

BASE_DIR = os.path.dirname(__file__)
HAAR_FILE = os.path.join(BASE_DIR, "haarcascade_frontalface_default.xml")

print("Testing Haar file:", HAAR_FILE)

face_cascade = cv2.CascadeClassifier(HAAR_FILE)
if face_cascade.empty():
    print("❌ Failed to load Haarcascade file.")
else:
    print("✅ Haarcascade file loaded successfully!")
